﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestProjectModels;

namespace TestProjectDataManager.IBAL
{
    public interface IHomeBAL
    {
        List<TestListModel> GetDetailsList();

        TestListModel GetProviderDetails(int ProviderId);
    }
}
