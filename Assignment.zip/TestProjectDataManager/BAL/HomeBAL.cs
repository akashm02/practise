﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestProjectDataManager.DataManager;
using TestProjectDataManager.IBAL;
using TestProjectDataManager.IDataManager;
using TestProjectModels;

namespace TestProjectDataManager.BAL
{
    public class HomeBAL : IHomeBAL
    {
        public HomeRepository _HomeRepository;

        public HomeBAL(IDBManager dbManager)
        {
            _HomeRepository = new HomeRepository(dbManager);
        }

        public List<TestListModel> GetDetailsList()
        {
            List<TestListModel> model = new List<TestListModel>();

            model = _HomeRepository.GetDetailsList();

            return model;
        }

        public TestListModel GetProviderDetails(int ProviderId)
        {
            TestListModel model = new TestListModel();
            model = _HomeRepository.GetProviderDetails(ProviderId);

            return model;


        }
    }
}
