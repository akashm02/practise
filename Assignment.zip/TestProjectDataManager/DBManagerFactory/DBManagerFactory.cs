﻿//using MySql.Data.MySqlClient;
//using System;
//using System.Collections.Generic;
//using System.Data.Common;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using TestProjectDataManager.DataManager;
//using TestProjectDataManager.IDataManager;
using MySql.Data.MySqlClient;
using TestProjectDataManager.DataManager;
using TestProjectDataManager.IDataManager;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestProjectDataManager.DBManagerFactory
{
    public class DBManagerFactory
    {
        public IDBManager GetDBManager(string connectionString)
        {
            DbConnection dbconn = new MySqlConnection(connectionString);
            return new DBManager(dbconn);
        }
    }
}
