﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestProjectModels;

namespace TestProjectDataManager.IDataManager
{
    public interface IHomeRepository
    {
        List<TestListModel> GetDetailsList();

        TestListModel GetProviderDetails(int ProviderId);
    }
}
