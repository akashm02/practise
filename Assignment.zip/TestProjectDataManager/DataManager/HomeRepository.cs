﻿using NLog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestProjectDataManager.IDataManager;
using TestProjectModels;

namespace TestProjectDataManager.DataManager
{
    public class HomeRepository : IHomeRepository
    {
        readonly IDBManager _IDbManager;
        private static Logger _logger = LogManager.GetCurrentClassLogger();

        public HomeRepository(IDBManager iDbManager)
        {
            _IDbManager = iDbManager;
        }

        public List<TestListModel> GetDetailsList()
        {
            List<TestListModel> testList = new List<TestListModel>();
            _IDbManager.InitDbCommand("sp_get_providerlist");

            try
            {
                DataTable dt = _IDbManager.ExecuteDataTable();

                foreach (DataRow dr in dt.Rows)
                {
                    TestListModel model = new TestListModel();

                    model.ProviderId = Convert.ToInt32(dr["providers_id"]);
                    model.NpiNumber = Convert.ToString(dr["npi_number"]);
                    model.FirstName = Convert.ToString(dr["first_name"]);
                    model.LastName = Convert.ToString(dr["last_name"]);
                    model.Gender = Convert.ToString(dr["gender"]);
                    model.Speciality = Convert.ToString(dr["speciality"]);

                    testList.Add(model);
                }


            }
            catch (Exception ex)
            {
                _logger.Info(ex.Message);
            }

            return testList;
        }



        public TestListModel GetProviderDetails(int ProviderId)
        {
            TestListModel model = new TestListModel();

            _IDbManager.InitDbCommand("sp_get_provider_details")
                .AddCMDParam("providers_id_in", ProviderId);

            try
            {
                DataTable datatable = _IDbManager.ExecuteDataTable();

                foreach (DataRow dr in datatable.Rows)
                {
                    model.ProviderId = Convert.ToInt32(dr["providers_id"]);
                    model.NpiNumber = Convert.ToString(dr["npi_number"]);
                    model.FirstName = Convert.ToString(dr["first_name"]);
                    model.LastName = Convert.ToString(dr["last_name"]);
                    model.Gender = Convert.ToString(dr["gender"]);
                    model.Speciality = Convert.ToString(dr["speciality"]);

                }

            }
            catch (Exception ex)
            {
                _logger.Info(ex.Message);
            }
            return model;
        }

    }
}
