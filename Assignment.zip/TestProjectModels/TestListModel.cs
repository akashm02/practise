﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestProjectModels
{
    public class TestListModel
    {
        public int ProviderId { get; set; }
        public string NpiNumber { get; set; }
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Gender { get; set; }

        public string Speciality { get; set; }
    }
}
