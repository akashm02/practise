﻿using TestProject.Controllers;
using TestProjectDataManager.BAL;
using TestProjectDataManager.DBManagerFactory;
using TestProjectDataManager.IBAL;
using TestProjectDataManager.IDataManager;

namespace TestProject.Extensions
{
    internal static class ServiceCollectionExtension
    {

        public static IServiceCollection AddDataManagers(this IServiceCollection services)
        {
            services.AddScoped<IDBManager>(AddDBManager);

            services.AddScoped<IHomeBAL, HomeBAL>();    


            return services;
        }


        internal static IDBManager AddDBManager(IServiceProvider serviceProvider)
        {
            IConfiguration Configuration = serviceProvider.GetRequiredService<IConfiguration>();



            string dbconstr = Configuration.GetConnectionString("DBConnectionString");
            return new DBManagerFactory().GetDBManager(dbconstr);
        }
    }
}
