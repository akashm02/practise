﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
using System.Diagnostics;
using TestProject.Models;
using TestProjectDataManager.IBAL;
using TestProjectModels;

namespace TestProject.Controllers
{
    public class HomeController : Controller
    {
        readonly IConfiguration _IConfiguration;

        readonly ILogger<HomeController> _logger;

        private readonly IHomeBAL _IHomeBAL;

        public HomeController(ILogger<HomeController> logger, IHomeBAL ihomeBAL, IConfiguration iConfiguration)
        {
            _logger = logger;

            _IHomeBAL = ihomeBAL;

            _IConfiguration = iConfiguration; ;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public async Task<JsonResult> GetProviderDetails(string npi)
        {
            TestListModel model = new TestListModel();

            string url = _IConfiguration["Add_Provider"];

            string require = $"{url}&number={npi}";

            HttpClient client = new HttpClient();

            HttpResponseMessage response = await client.GetAsync(require);

            string rescontent = await response.Content.ReadAsStringAsync();

            JToken res = rescontent.ToObject<JToken>();

            foreach (JToken token in res["results"])
            {
                JToken basicdt = token["basic"];

                model.FirstName = basicdt["first_name"].ToString();
                model.LastName = basicdt["last_name"] != null ? basicdt["last_name"].ToString() : "";
                model.Gender = basicdt["gender"] != null ? basicdt["gender"].ToString() : "";

                JToken taxo = token["taxonomies"];

                model.Speciality = taxo[0]["desc"] != null ? taxo[0]["desc"].ToString() : "";

            }

            return Json(model);


        }

        [HttpGet]
        public JsonResult GetDetailsList()
        {
            List<TestListModel> userlist = new List<TestListModel>();

            userlist = _IHomeBAL.GetDetailsList();

            return Json(userlist);
        }

        [HttpGet]

        public JsonResult GetProviderDetails(int ProviderId)
        {
            TestListModel provider = new TestListModel();

            provider = _IHomeBAL.GetProviderDetails(ProviderId);

            return Json(provider);
        }




        //public IActionResult Privacy()
        //{
        //    return View();
        //}

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}