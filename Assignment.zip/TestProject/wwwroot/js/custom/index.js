﻿var providerListTable;


$(document).ready(function () {

    console.log("Entered")

    providerListTable = $("#provider_user_list_table").DataTable({
        paging: false,
        info: false,
        filter: false,
        data: [],
        columns: [
            { data: 'NpiNumber' },

            { data: 'FirstName' },

            { data: 'LastName' },

            { data: 'Gender' },

            { data: 'Speciality' },

            {
                data: null,
                className: "text-center",
                render: function (data, type, row) {
                    if (type === 'display') {
                        return `<ul class="list-unstyled hstack gap-1 mb-0">
                               <li data-bs-toggle="tooltip" data-bs-placement="top" title="Edit">
                                                                                    <a onclick="OpenEditProviderForUserList(${row.ProviderId})" class="btn btn-sm btn-soft-primary"><i class="mdi mdi-pencil-outline"></i></a>
                                                                                </li>
                                                                                <li data-bs-toggle="tooltip" data-bs-placement="top" title="Delete">
                                                                                    <a onclick="DeleteUser(${row.ProviderId})" class="btn btn-sm btn-soft-danger"><i class="mdi mdi-delete-outline"></i></a>
                                                                                </li>
                                                                            </ul>`;
                    }
                    else {
                        return data;
                    }
                }
            }

        ],
    });
    GetProviderDetailslist();
});

function GetProviderDetailslist() {
    $.ajax({
        url: "/Home/GetDetailsList",
        type: "GET",
        contentType: "application/json",
        success: function (result) {

            providerListTable.clear().rows.add(result).draw(false);
        },
        error: function (xhr, status, error) {
            if (xhr.status == 462) {
                AuthenticateUser(xhr.responseJSON);
            } else if (xhr.status == 463) {
                CookieNotFound(xhr.responseJSON);
            }
        }
    });
}

function OpenEditProviderModal() {
    $('#editProviderModal').modal('show');
}

function CloseEditProviderModal() {
    $('#editProviderModal').modal('hide');
}


function OpenEditProviderForUserList(ProviderId) {
    OpenEditProviderModal();
    var oModel = GetUserDetails(ProviderId);
    BindProviderModalForEdit(oModel);
    debugger
}

function BindProviderModalForEdit(oModel) {
    debugger
    $("#hd-edit-provider-id").val(oModel.ProviderId);
    $("#txt-npinumber").val(oModel.NpiNumber);
    $("#txt-edit-firstname").val(oModel.FirstName);
    $("#txt-edit-lastname").val(oModel.LastName);
    $("#txt-edit-gender").val(oModel.Gender);
    $("#txt-edit-speciality").val(oModel.Speciality);
}

function GetUserDetails(ProviderId) {

    var oResult;
    $.ajax({
        url: "/Home/GetProviderDetails?ProviderId=" + ProviderId,
        type: "GET",
        contentType: "application/json",
        dataType: "json",
        cache: false,
        async: false,
        success: function (result) {
            oResult = result;
        },
        error: function (xhr, status, error) {
            if (xhr.status == 462) {
                AuthenticateUser(xhr.responseJSON);
            } else if (xhr.status == 463) {
                CookieNotFound(xhr.responseJSON);
            }
        }
    });
    return oResult;
}

