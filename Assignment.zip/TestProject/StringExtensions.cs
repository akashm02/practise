﻿using Newtonsoft.Json;

namespace TestProject
{
    public static class StringExtensions
    {
        public static T ToObject<T>(this string str)
        {
            T result = default;
            if (!string.IsNullOrEmpty(str))
            {
                result = JsonConvert.DeserializeObject<T>(str);
            }

            return result;
        }

        public static string ToJsonString(this Object obj)
        {
            return obj.ToJsonString(false);
        }

        public static string ToJsonString(this Object obj, bool needformatting)
        {
            string result = null;

            if (obj != null)
            {
                Formatting formatting = needformatting ? Formatting.Indented : Formatting.None;
                result = JsonConvert.SerializeObject(obj, formatting);
            }
            return result;
        }
    }
}
